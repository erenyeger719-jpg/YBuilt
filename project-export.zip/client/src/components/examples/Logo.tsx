import Logo from '../Logo'

export default function LogoExample() {
  return (
    <div className="p-8 bg-background">
      <Logo animate={true} />
    </div>
  )
}
