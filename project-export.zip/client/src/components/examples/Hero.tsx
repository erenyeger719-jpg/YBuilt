import Hero from '../Hero'

export default function HeroExample() {
  return (
    <div className="min-h-screen">
      <Hero />
    </div>
  )
}
