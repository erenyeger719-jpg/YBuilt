import Showcase from '../Showcase'

export default function ShowcaseExample() {
  return (
    <div className="bg-background">
      <Showcase />
    </div>
  )
}
