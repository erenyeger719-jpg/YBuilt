import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { jobQueue } from "./queue";
import { insertJobSchema, insertUserSchema, jobFinalizationSchema, draftSchema, regenerationScopeSchema, insertSupportTicketSchema, defaultSettings, settingsSchema } from "@shared/schema";
import crypto from "crypto";
import fs from "fs/promises";
import path from "path";
import { z } from "zod";
import multer from "multer";
import archiver from "archiver";
import { validateAndResolvePath } from "./utils/paths.js";
import { logger } from "./middleware/logging.js";
import { metricsHandler } from "./telemetry";
import { initDb } from "./db.js";
import authRoutes from "./routes/auth.js";
import chatRouter from "./routes/chat.js";
import executeRouter from "./routes/execute.js";
import projectsRouter from "./routes/projects.js";
import { initializeSocket } from "./socket.js";

// Workspace readiness check helper
async function checkWorkspaceReady(jobId: string): Promise<{ ready: boolean; retryAfter?: number }> {
  const indexPath = path.join(process.cwd(), "public", "previews", jobId, "index.html");
  
  try {
    await fs.access(indexPath, fs.constants.R_OK);
    const stats = await fs.stat(indexPath);
    
    if (stats.size === 0) {
      logger.info(`[WORKSPACE] Preview file exists but is empty for job ${jobId}`);
      return { ready: false, retryAfter: 1000 };
    }
    
    logger.info(`[WORKSPACE] Workspace ready for job ${jobId}`);
    return { ready: true };
  } catch (error) {
    logger.info({ error, jobId }, `[WORKSPACE] Preview file not accessible for job ${jobId}`);
    return { ready: false, retryAfter: 1000 };
  }
}

const upload = multer({
  dest: "public/uploads/",
  limits: { fileSize: 25 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      "image/jpeg", "image/png", "image/gif", "image/webp",
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "text/html", "text/plain"
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type"));
    }
  }
});

const supportUpload = multer({
  dest: "data/support/attachments/",
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit for support attachments
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      "image/jpeg", "image/png", "image/gif", "image/webp",
      "application/pdf",
      "text/plain",
      "video/mp4", "video/webm"
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type for support attachment"));
    }
  }
});

// Security validation helpers
function validateJobId(jobId: string): { valid: boolean; error?: string } {
  // Must match UUID format: alphanumeric and hyphens only
  if (!/^[a-z0-9-]+$/i.test(jobId)) {
    return { valid: false, error: "Invalid job ID format" };
  }
  
  // Must be exactly 36 characters (UUID length)
  if (jobId.length !== 36) {
    return { valid: false, error: "Invalid job ID length" };
  }
  
  return { valid: true };
}


function isProtectedFile(resolvedPath: string, workspaceDir: string): boolean {
  // Protect index.html from deletion
  const indexHtmlPath = path.resolve(workspaceDir, 'index.html');
  return resolvedPath === indexHtmlPath;
}

// Razorpay configuration
const RAZORPAY_MODE = process.env.RAZORPAY_MODE || 'mock';

// Razorpay initialization
let razorpay: any = null;
if (RAZORPAY_MODE !== 'mock') {
  try {
    const Razorpay = require('razorpay');
    razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
    logger.info(`[RAZORPAY] Initialized with ${RAZORPAY_MODE} mode`);
  } catch (error) {
    logger.error({ error, mode: RAZORPAY_MODE }, `[RAZORPAY] Failed to initialize Razorpay in ${RAZORPAY_MODE} mode`);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Log Razorpay mode on server startup
  logger.info(`[RAZORPAY] Running in ${RAZORPAY_MODE} mode`);
  
  // Register authentication routes
  app.use("/api/auth", authRoutes);
  
  // Register chat routes
  app.use("/api/chat", chatRouter);
  
  // Register code execution routes
  app.use("/api/execute", executeRouter);
  
  // Register project collaboration routes
  app.use("/api/projects", projectsRouter);
  
  // Job generation endpoint
  app.post("/api/generate", async (req, res) => {
    try {
      // For backward compatibility, default to demo user if userId not provided
      const bodyWithUserId = {
        ...req.body,
        userId: req.body.userId || "demo"
      };
      
      const validation = insertJobSchema.safeParse(bodyWithUserId);
      
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid request", details: validation.error });
      }

      const job = await storage.createJob(validation.data);
      
      // [JOB_RESPONSE] Debug logging before response
      logger.info({ jobId: job.id, length: job.id.length }, '[JOB_RESPONSE] Job created with ID');
      
      // Validate jobId before sending response
      if (job.id.length !== 36) {
        const error = `[JOB_RESPONSE] ERROR: Job ID length is ${job.id.length}, expected 36. ID: ${job.id}`;
        logger.error(error);
        return res.status(500).json({ error: "Invalid job ID generated" });
      }
      
      // Add to job queue for processing
      await jobQueue.addJob(job.id, job.prompt);
      
      const responseData = { jobId: job.id, status: job.status };
      logger.info({ responseData, jobIdLength: responseData.jobId.length }, '[JOB_RESPONSE] Sending response');
      
      res.json(responseData);
    } catch (error) {
      logger.error({ error }, "Error creating job");
      res.status(500).json({ error: "Failed to create job" });
    }
  });

  // Get job status
  app.get("/api/jobs/:jobId", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.jobId);
      
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      res.json({
        id: job.id,
        prompt: job.prompt,
        status: job.status,
        result: job.result,
        error: job.error,
        settings: job.settings,
        createdAt: job.createdAt,
      });
    } catch (error) {
      logger.error({ error }, "Error fetching job");
      res.status(500).json({ error: "Failed to fetch job" });
    }
  });

  // Finalize job - save edits and move to editing state
  app.post("/api/jobs/:jobId/finalize", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.jobId);
      
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      if (job.status !== "ready_for_finalization") {
        return res.status(400).json({ error: "Job is not ready for finalization" });
      }

      // Validate request body
      const validationResult = jobFinalizationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Invalid finalization data", 
          details: validationResult.error.errors 
        });
      }

      const finalizationSettings = validationResult.data;

      await storage.updateJob(req.params.jobId, {
        status: "editing",
        settings: JSON.stringify(finalizationSettings),
      });

      res.json({ success: true, status: "editing" });
    } catch (error) {
      logger.error({ error }, "Error finalizing job");
      res.status(500).json({ error: "Failed to finalize job" });
    }
  });

  // Save draft edits without changing status
  app.post("/api/jobs/:jobId/save-draft", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.jobId);
      
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      // Validate request body
      const validationResult = jobFinalizationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Invalid draft data", 
          details: validationResult.error.errors 
        });
      }

      const draftSettings = validationResult.data;

      await storage.updateJob(req.params.jobId, {
        settings: JSON.stringify(draftSettings),
      });

      res.json({ success: true });
    } catch (error) {
      logger.error({ error }, "Error saving draft");
      res.status(500).json({ error: "Failed to save draft" });
    }
  });

  // Upload files for AI Design Assistant
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const { jobId, userId } = req.body;
      if (!jobId || !userId) {
        return res.status(400).json({ error: "Missing jobId or userId" });
      }

      const uploadDir = path.join(process.cwd(), "public", "uploads", userId, jobId);
      await fs.mkdir(uploadDir, { recursive: true });

      const filePath = path.join(uploadDir, req.file.originalname);
      await fs.rename(req.file.path, filePath);

      const asset = {
        url: `/uploads/${userId}/${jobId}/${req.file.originalname}`,
        name: req.file.originalname,
        mime: req.file.mimetype,
        size: req.file.size,
        parsed: {
          textPreview: req.file.mimetype.startsWith("text/") ? 
            (await fs.readFile(filePath, "utf-8")).substring(0, 500) : undefined,
          warnings: []
        }
      };

      await storage.addUploadedAsset(jobId, asset);

      res.json(asset);
    } catch (error) {
      logger.error({ error }, "Upload error");
      res.status(500).json({ error: "Upload failed" });
    }
  });

  // Create draft for library
  app.post("/api/drafts", async (req, res) => {
    try {
      const { jobId, userId, ...draftData } = req.body;
      
      if (!jobId || !userId) {
        return res.status(400).json({ error: "Missing jobId or userId" });
      }

      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      const draft = await storage.createDraft({
        jobId,
        userId,
        thumbnail: job.result || undefined,
        ...draftData
      });

      res.json({ ok: true, draftId: draft.draftId, libraryEntry: draft });
    } catch (error) {
      logger.error({ error }, "Error creating draft");
      res.status(500).json({ error: "Failed to create draft" });
    }
  });

  // Get drafts for library
  app.get("/api/drafts/:userId", async (req, res) => {
    try {
      const drafts = await storage.getDrafts(req.params.userId);
      res.json(drafts);
    } catch (error) {
      logger.error({ error }, "Error fetching drafts");
      res.status(500).json({ error: "Failed to fetch drafts" });
    }
  });

  // Regenerate job with scope
  app.post("/api/jobs/:jobId/regenerate", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.jobId);
      
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      const { scope, draftEdits } = req.body;
      
      const scopeValidation = regenerationScopeSchema.safeParse(scope);
      if (!scopeValidation.success) {
        return res.status(400).json({ error: "Invalid regeneration scope" });
      }

      await storage.updateJob(req.params.jobId, {
        settings: JSON.stringify(draftEdits),
        status: "queued"
      });

      await jobQueue.addJob(req.params.jobId, job.prompt, scopeValidation.data);

      res.json({ jobId: req.params.jobId, queued: true });
    } catch (error) {
      logger.error({ error }, "Error regenerating job");
      res.status(500).json({ error: "Failed to regenerate" });
    }
  });

  // Select and open workspace
  app.post("/api/jobs/:jobId/select", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.jobId);
      
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      const { draftEdits } = req.body;

      await storage.updateJob(req.params.jobId, {
        settings: JSON.stringify(draftEdits),
        status: "editing"
      });

      const workspaceDir = path.join(process.cwd(), "data", "workspaces", req.params.jobId);
      await fs.mkdir(workspaceDir, { recursive: true });

      const manifest = {
        name: draftEdits?.title || "Untitled Project",
        description: draftEdits?.description || "",
        entryPoint: "index.html",
        dependencies: {}
      };

      await fs.writeFile(
        path.join(workspaceDir, "manifest.json"),
        JSON.stringify(manifest, null, 2)
      );

      // Check workspace readiness with timeout
      logger.info(`[WORKSPACE] Checking readiness for job ${req.params.jobId}`);
      const maxWaitTime = 10000; // 10 seconds max
      const startTime = Date.now();
      
      while (Date.now() - startTime < maxWaitTime) {
        const readiness = await checkWorkspaceReady(req.params.jobId);
        
        if (readiness.ready) {
          logger.info(`[WORKSPACE] Workspace ready for job ${req.params.jobId}`);
          return res.json({ 
            status: 'success',
            ok: true, 
            workspaceUrl: `/workspace/${req.params.jobId}`,
            workspaceReady: true 
          });
        }
        
        // If not ready yet and we haven't timed out, wait briefly
        if (Date.now() - startTime + (readiness.retryAfter || 1000) < maxWaitTime) {
          await new Promise(resolve => setTimeout(resolve, readiness.retryAfter || 1000));
        } else {
          break;
        }
      }
      
      // If we get here, workspace is not ready after timeout
      logger.info(`[WORKSPACE] Workspace not ready after timeout for job ${req.params.jobId}`);
      res.json({
        status: 'pending',
        retryAfter: 1000,
        message: 'Workspace is being prepared, please retry'
      });
    } catch (error) {
      logger.error({ error }, "Error selecting job");
      res.status(500).json({ error: "Failed to select" });
    }
  });

  // Get workspace files
  app.get("/api/workspace/:jobId/files", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.jobId);
      
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      // Check workspace readiness first
      const readiness = await checkWorkspaceReady(req.params.jobId);
      
      if (!readiness.ready) {
        logger.info(`[WORKSPACE] Files not ready for job ${req.params.jobId}`);
        res.setHeader('Retry-After', (readiness.retryAfter || 1000) / 1000); // Convert to seconds
        return res.status(202).json({ 
          error: "Workspace not ready", 
          retryAfter: readiness.retryAfter || 1000 
        });
      }

      const previewPath = job.result?.replace("/previews/", "");
      if (!previewPath) {
        return res.status(404).json({ error: "No preview available" });
      }

      const previewDir = path.join(process.cwd(), "public", "previews", req.params.jobId);
      const indexPath = path.join(previewDir, "index.html");

      try {
        const content = await fs.readFile(indexPath, "utf-8");
        
        const files = [
          {
            path: "index.html",
            content,
            language: "html"
          }
        ];

        // Check for prompt files
        const promptsDir = path.join(process.cwd(), "data", "workspaces", req.params.jobId, "prompts");
        try {
          const promptFiles = await fs.readdir(promptsDir);
          
          // Read prompt files and add to files array (newest first)
          const promptFileData = await Promise.all(
            promptFiles.map(async (fileName) => {
              try {
                const filePath = path.join(promptsDir, fileName);
                const content = await fs.readFile(filePath, "utf-8");
                const stats = await fs.stat(filePath);
                
                return {
                  path: `prompts/${fileName}`,
                  content,
                  language: "markdown",
                  type: "prompt",
                  createdAt: stats.mtime.toISOString()
                };
              } catch (err) {
                return null;
              }
            })
          );

          // Filter out nulls and sort by creation time (newest first)
          const validPromptFiles = promptFileData
            .filter((f): f is NonNullable<typeof f> => f !== null)
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

          // Add prompt files at the beginning
          files.unshift(...validPromptFiles);
        } catch (error) {
          // No prompts directory yet, that's ok
        }
        
        res.json({
          files,
          manifest: {
            name: "Generated Site",
            description: job.prompt,
            entryPoint: "index.html"
          }
        });
      } catch (error) {
        res.status(404).json({ error: "Workspace files not found" });
      }
    } catch (error) {
      logger.error({ error }, "Error fetching workspace files");
      res.status(500).json({ error: "Failed to fetch workspace files" });
    }
  });

  // Get job logs
  app.get("/api/jobs/:jobId/logs", async (req, res) => {
    try {
      const logFile = path.join(process.cwd(), "data", "jobs", req.params.jobId, "logs.jsonl");
      
      try {
        const content = await fs.readFile(logFile, "utf-8");
        const logs = content.trim().split("\n").filter(Boolean).map(line => JSON.parse(line));
        res.json(logs);
      } catch (error) {
        res.json([]);
      }
    } catch (error) {
      logger.error({ error }, "Error fetching logs");
      res.status(500).json({ error: "Failed to fetch logs" });
    }
  });

  // Get build trace snapshot
  app.get("/api/jobs/:jobId/build-trace", async (req, res) => {
    try {
      const { jobId } = req.params;
      const tracePath = path.join(process.cwd(), "data", "jobs", jobId, "build-trace.json");
      
      try {
        const data = await fs.readFile(tracePath, "utf-8");
        const trace = JSON.parse(data);
        res.json(trace);
      } catch (error) {
        // No trace file yet, return initial state
        const { BuildStage } = await import("@shared/schema");
        res.json({
          jobId,
          currentStage: BuildStage.GENERATION,
          stages: {
            [BuildStage.GENERATION]: { 
              stage: BuildStage.GENERATION, 
              status: "pending", 
              logs: [] 
            },
            [BuildStage.ASSEMBLY]: { 
              stage: BuildStage.ASSEMBLY, 
              status: "pending", 
              logs: [] 
            },
            [BuildStage.LINT]: { 
              stage: BuildStage.LINT, 
              status: "pending", 
              logs: [] 
            },
            [BuildStage.TEST]: { 
              stage: BuildStage.TEST, 
              status: "pending", 
              logs: [] 
            },
            [BuildStage.BUNDLE]: { 
              stage: BuildStage.BUNDLE, 
              status: "pending", 
              logs: [] 
            },
          },
          summaryLog: ""
        });
      }
    } catch (error) {
      logger.error({ error }, "Error fetching build trace");
      res.status(500).json({ error: "Failed to fetch build trace" });
    }
  });

  // SSE stream for build trace updates
  app.get("/api/jobs/:jobId/build-trace/stream", async (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const { BuildStage } = await import("@shared/schema");

    // Send sample events every 2 seconds
    let eventCount = 0;
    const interval = setInterval(() => {
      eventCount++;

      if (eventCount === 1) {
        // Stage status update
        res.write(`data: ${JSON.stringify({
          type: "stage-status",
          stage: BuildStage.LINT,
          status: "running",
        })}\n\n`);
      } else if (eventCount === 2) {
        // Log entry
        res.write(`data: ${JSON.stringify({
          type: "log",
          stage: BuildStage.LINT,
          log: {
            timestamp: new Date().toISOString(),
            level: "info",
            message: "Running ESLint checks...",
          },
        })}\n\n`);
      } else if (eventCount === 3) {
        // Another log entry
        res.write(`data: ${JSON.stringify({
          type: "log",
          stage: BuildStage.LINT,
          log: {
            timestamp: new Date().toISOString(),
            level: "info",
            message: "No linting errors found",
          },
        })}\n\n`);
      } else if (eventCount === 4) {
        // Complete stage
        res.write(`data: ${JSON.stringify({
          type: "stage-status",
          stage: BuildStage.LINT,
          status: "success",
        })}\n\n`);
      } else if (eventCount >= 5) {
        // Complete event
        res.write(`data: ${JSON.stringify({
          type: "complete",
        })}\n\n`);
        clearInterval(interval);
        res.end();
      }
    }, 2000);

    req.on("close", () => {
      clearInterval(interval);
    });
  });

  // Download build trace transcript
  app.get("/api/jobs/:jobId/build-trace/download", async (req, res) => {
    try {
      const { BuildStage } = await import("@shared/schema");
      
      // Generate transcript from all logs
      const transcript = [
        "Build Trace Transcript",
        `Job ID: ${req.params.jobId}`,
        `Generated: ${new Date().toISOString()}`,
        "",
        "=".repeat(80),
        "",
      ];

      // Mock data - in real implementation, fetch from storage
      const stages = [
        BuildStage.GENERATION,
        BuildStage.ASSEMBLY,
        BuildStage.LINT,
        BuildStage.TEST,
        BuildStage.BUNDLE,
      ];

      for (const stage of stages) {
        transcript.push(`Stage: ${stage}`);
        transcript.push("-".repeat(40));
        transcript.push("[2024-01-01 10:00:00] INFO: Sample log entry for " + stage);
        transcript.push("");
      }

      transcript.push("=".repeat(80));
      transcript.push("End of transcript");

      const content = transcript.join("\n");
      
      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", `attachment; filename="build-trace-${req.params.jobId}.txt"`);
      res.send(content);
    } catch (error) {
      logger.error({ error }, "Error generating transcript");
      res.status(500).json({ error: "Failed to generate transcript" });
    }
  });

  // Get drafts for user
  app.get("/api/drafts/:userId", async (req, res) => {
    try {
      const drafts = await storage.getDrafts(req.params.userId);
      res.json(drafts);
    } catch (error) {
      logger.error({ error }, "Error fetching drafts");
      res.status(500).json({ error: "Failed to fetch drafts" });
    }
  });

  // Get Razorpay key (mock mode)
  app.get("/api/razorpay_key", (req, res) => {
    // In mock mode, return a test key
    res.json({ 
      key: process.env.RAZORPAY_KEY_ID || "rzp_test_mock_key_12345",
      isMockMode: !process.env.RAZORPAY_KEY_ID 
    });
  });

  // Razorpay webhook
  app.post("/webhooks/razorpay", async (req, res) => {
    try {
      const signature = req.headers["x-razorpay-signature"] as string;
      const secret = process.env.RAZORPAY_WEBHOOK_SECRET || "mock_webhook_secret";

      // Get raw body (preserved by express.raw middleware)
      const rawBody = req.body as Buffer;
      
      // Verify signature (HMAC SHA256) using raw body
      const expectedSignature = crypto
        .createHmac("sha256", secret)
        .update(rawBody)
        .digest("hex");

      if (signature !== expectedSignature) {
        logger.error("Invalid webhook signature");
        return res.status(400).json({ error: "Invalid signature" });
      }

      // Parse JSON from raw body
      const body = JSON.parse(rawBody.toString());
      const event = body.event;
      const payload = body.payload;

      if (event === "payment.captured") {
        const paymentId = payload.payment.entity.id;
        const amount = payload.payment.entity.amount / 100; // Convert from paise to rupees
        const userId = payload.payment.entity.notes?.userId || "demo";

        // Update user credits
        const currentCredits = await storage.getUserCredits(userId);
        const creditsToAdd = Math.floor(amount / 799); // 1 credit per ₹799
        await storage.updateUserCredits(userId, currentCredits + creditsToAdd);

        // Log payment
        const logEntry = `${new Date().toISOString()} - Payment captured: ${paymentId}, User: ${userId}, Amount: ₹${amount}, Credits added: ${creditsToAdd}\n`;
        await fs.appendFile(
          path.join(process.cwd(), "data", "payments.log"),
          logEntry
        );

        logger.info(`Payment processed: ${paymentId} for user ${userId}`);
      }

      res.json({ status: "ok" });
    } catch (error) {
      logger.error({ error }, "Webhook error");
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  // Simulate payment webhook (mock mode only)
  app.post("/api/payments/simulate", async (req, res) => {
    if (RAZORPAY_MODE !== 'mock') {
      return res.status(403).json({ error: 'Simulate endpoint only available in mock mode' });
    }
    
    try {
      const { userId, amount, orderId } = req.body;
      
      if (!userId || !amount) {
        return res.status(400).json({ error: 'userId and amount are required' });
      }
      
      // Simulate webhook payload
      const mockWebhookPayload = {
        event: 'payment.captured',
        payload: {
          payment: {
            entity: {
              id: `pay_mock_${Date.now()}`,
              order_id: orderId || `order_mock_${Date.now()}`,
              amount: amount * 100, // paise
              status: 'captured'
            }
          }
        }
      };
      
      // Calculate credits (1 credit per ₹799 or equivalent)
      const credits = Math.floor(amount / 799);
      
      // Add credits to user
      await storage.addCredits(userId, credits);
      
      // Log simulated payment
      const logEntry = {
        timestamp: new Date().toISOString(),
        mode: 'simulated',
        userId,
        amount,
        credits,
        orderId,
        paymentId: mockWebhookPayload.payload.payment.entity.id
      };
      
      await fs.appendFile(
        path.join(process.cwd(), 'data', 'payments.log'),
        JSON.stringify(logEntry) + '\n'
      );
      
      logger.info(logEntry, '[PAYMENT_SIMULATE]');
      
      res.json({
        success: true,
        credits,
        paymentId: mockWebhookPayload.payload.payment.entity.id,
        message: 'Payment simulated successfully'
      });
      
    } catch (error) {
      logger.error({ error }, 'Error simulating payment');
      res.status(500).json({ error: 'Failed to simulate payment' });
    }
  });

  // Get user credits
  app.get("/api/credits/:userId", async (req, res) => {
    try {
      const credits = await storage.getUserCredits(req.params.userId);
      res.json({ userId: req.params.userId, credits });
    } catch (error) {
      logger.error({ error }, "Error fetching credits");
      res.status(500).json({ error: "Failed to fetch credits" });
    }
  });

  // Auth: Sign in (mock mode)
  app.post("/api/auth/signin", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password required" });
      }

      // Check if user exists
      let user = await storage.getUserByEmail(email);
      
      if (!user) {
        // In mock mode, auto-create user if they don't exist
        const username = email.split('@')[0];
        user = await storage.createUser({
          email,
          username,
          password // In production, hash this password
        });
        logger.info(`Mock auth: Auto-created user ${email}`);
      }

      // In mock mode, we don't actually verify password
      // In production, you'd verify against hashed password
      
      const credits = await storage.getUserCredits(user.id);
      
      res.json({
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          credits
        }
      });
    } catch (error) {
      logger.error({ error }, "Sign in error");
      res.status(500).json({ error: "Sign in failed" });
    }
  });

  // Auth: Sign up (mock mode)
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password required" });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({ error: "User already exists" });
      }

      // Create username from email
      const username = email.split('@')[0];
      
      // Create user
      const user = await storage.createUser({
        email,
        username,
        password // In production, hash this password
      });

      // Initialize credits
      const credits = await storage.getUserCredits(user.id);

      res.json({
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          credits
        }
      });
    } catch (error) {
      logger.error({ error }, "Sign up error");
      res.status(500).json({ error: "Sign up failed" });
    }
  });

  // Get current user
  app.get("/api/me", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const token = authHeader.substring(7); // Remove 'Bearer ' prefix
      
      // Validate mock token format (header.payload.signature)
      const parts = token.split('.');
      if (parts.length !== 3) {
        return res.status(401).json({ error: "Invalid token" });
      }

      try {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
        
        // Check expiration
        if (payload.exp && payload.exp < Date.now()) {
          return res.status(401).json({ error: "Token expired" });
        }

        // Get user by email from token
        const user = await storage.getUserByEmail(payload.email);
        
        if (!user) {
          return res.status(401).json({ error: "User not found" });
        }

        const credits = await storage.getUserCredits(user.id);

        res.json({
          user: {
            id: user.id,
            email: user.email,
            username: user.username,
            credits
          }
        });
      } catch (error) {
        return res.status(401).json({ error: "Invalid token" });
      }
    } catch (error) {
      logger.error({ error }, "Get current user error");
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // Get user projects (mock data for now)
  app.get("/api/projects", async (req, res) => {
    try {
      // For now, return empty array as we don't have project storage yet
      // In a real implementation, this would fetch from storage
      res.json([]);
    } catch (error) {
      logger.error({ error }, "Error fetching projects");
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  // Get user profile with projects
  app.get("/api/users/:userId/profile", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Get user's jobs/projects
      const jobs = await storage.getUserJobs(req.params.userId);
      
      // Transform jobs to projects format
      const projects = jobs.map(job => ({
        id: job.id,
        name: job.settings ? JSON.parse(job.settings).title || "Untitled" : "Untitled",
        thumbnail: job.result || "/previews/default-thumbnail.jpg",
        createdAt: job.createdAt,
        lastPublished: job.status === "published" ? job.updatedAt : null,
        status: job.status,
      }));

      // Get settings for SSH keys and secrets counts
      const settings = await storage.getSettings(req.params.userId);
      const sshKeysCount = settings.security.sshKeys?.length || 0;
      const secretsCount = settings.security.apiKeys?.length || 0;

      res.json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName || "",
          lastName: user.lastName || "",
          bio: user.bio || "",
          avatar: user.avatar || null,
          publicProfile: user.publicProfile || false,
          emailVerified: user.emailVerified || false,
          roles: user.roles || [],
        },
        projects,
        counts: {
          sshKeys: sshKeysCount,
          secrets: secretsCount,
        }
      });
    } catch (error) {
      logger.error({ error }, "Error fetching user profile");
      res.status(500).json({ error: "Failed to fetch user profile" });
    }
  });


  // Upload avatar
  const avatarUpload = multer({
    dest: "public/uploads/avatars/",
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: (req, file, cb) => {
      const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error("Invalid file type. Only images are allowed"));
      }
    }
  });

  app.post("/api/users/:userId/avatar", avatarUpload.single("avatar"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const { userId } = req.params;
      const uploadDir = path.join(process.cwd(), "public", "uploads", "avatars");
      await fs.mkdir(uploadDir, { recursive: true });

      const ext = path.extname(req.file.originalname);
      const fileName = `${userId}${ext}`;
      const filePath = path.join(uploadDir, fileName);
      
      await fs.rename(req.file.path, filePath);

      const avatarUrl = `/uploads/avatars/${fileName}`;
      
      const updatedUser = await storage.updateUser(userId, { avatar: avatarUrl });

      res.json({
        success: true,
        avatarUrl,
        user: {
          id: updatedUser.id,
          avatar: updatedUser.avatar,
        }
      });
    } catch (error) {
      logger.error({ error }, "Avatar upload error");
      res.status(500).json({ error: "Avatar upload failed" });
    }
  });

  // Delete project
  app.delete("/api/projects/:projectId", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.projectId);
      
      if (!job) {
        return res.status(404).json({ error: "Project not found" });
      }

      // In a real implementation, we'd delete the job and associated files
      // For now, just update status to indicate it's deleted
      await storage.updateJob(req.params.projectId, { status: "deleted" });

      res.json({ success: true });
    } catch (error) {
      logger.error({ error }, "Error deleting project");
      res.status(500).json({ error: "Failed to delete project" });
    }
  });

  // Get workspace theme
  app.get("/api/workspace/:jobId/theme", async (req, res) => {
    try {
      const { jobId } = req.params;
      
      if (!jobId) {
        return res.status(400).json({ error: "Job ID is required" });
      }

      const theme = await storage.getProjectTheme(jobId);
      
      // Theme is always returned (default theme if no custom theme exists)
      res.json(theme);
    } catch (error) {
      logger.error({ error }, "Error fetching workspace theme");
      res.status(500).json({ error: "Failed to fetch workspace theme" });
    }
  });

  // Save workspace theme
  app.post("/api/workspace/:jobId/theme", async (req, res) => {
    try {
      const { jobId } = req.params;
      
      if (!jobId) {
        return res.status(400).json({ error: "Job ID is required" });
      }

      // Validate theme data
      const { projectThemeSchema } = await import("@shared/schema");
      const theme = projectThemeSchema.parse(req.body);

      await storage.saveProjectTheme(jobId, theme);

      res.json({ success: true, theme });
    } catch (error: any) {
      logger.error({ error }, "Error saving workspace theme");
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid theme data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to save workspace theme" });
    }
  });

  // System Status
  app.get("/api/status", async (req, res) => {
    try {
      const status = await storage.getSystemStatus();
      res.json(status);
    } catch (error) {
      logger.error({ error }, "Error fetching system status");
      res.status(500).json({ error: "Failed to fetch system status" });
    }
  });

  // Prometheus metrics endpoint
  app.get("/api/metrics", metricsHandler);

  // Support Tickets
  app.post("/api/support/tickets", supportUpload.array("attachments", 5), async (req, res) => {
    try {
      const { userId, type, subject, message } = req.body;
      
      if (!userId || !type || !message) {
        return res.status(400).json({ error: "Missing required fields: userId, type, message" });
      }

      // Process uploaded attachments
      const attachments = [];
      if (req.files && Array.isArray(req.files)) {
        for (const file of req.files) {
          const attachmentDir = path.join(process.cwd(), "data", "support", "attachments");
          await fs.mkdir(attachmentDir, { recursive: true });
          
          const fileName = `${Date.now()}-${file.originalname}`;
          const filePath = path.join(attachmentDir, fileName);
          await fs.rename(file.path, filePath);
          
          attachments.push({
            name: file.originalname,
            url: `/support/attachments/${fileName}`,
            size: file.size,
          });
        }
      }

      // Validate and create ticket
      const ticketData = {
        userId,
        type,
        subject: subject || "",
        message,
        attachments,
      };

      const validation = insertSupportTicketSchema.safeParse(ticketData);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid ticket data", 
          details: validation.error.errors 
        });
      }

      const ticket = await storage.createSupportTicket(validation.data);

      res.json({
        ticketId: ticket.id,
        status: ticket.status,
        message: "Support ticket created successfully",
      });
    } catch (error) {
      logger.error({ error }, "Error creating support ticket");
      res.status(500).json({ error: "Failed to create support ticket" });
    }
  });

  app.get("/api/support/tickets/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      
      if (!userId) {
        return res.status(400).json({ error: "User ID is required" });
      }

      const tickets = await storage.getSupportTickets(userId);
      res.json(tickets);
    } catch (error) {
      logger.error({ error }, "Error fetching support tickets");
      res.status(500).json({ error: "Failed to fetch support tickets" });
    }
  });

  // OAuth Mock Endpoints
  app.get("/api/auth/:provider", async (req, res) => {
    const { provider } = req.params;
    const validProviders = ["google", "apple", "facebook", "twitter", "github"];
    
    if (!validProviders.includes(provider.toLowerCase())) {
      return res.status(400).json({ error: "Invalid provider" });
    }

    // In MOCK_MODE, redirect to mock success
    // In production, this would initiate real OAuth flow
    const mockMode = !process.env.OAUTH_CLIENT_ID;
    
    if (mockMode) {
      return res.redirect(`/api/auth/mock-success?provider=${provider}`);
    }

    // Real OAuth flow would go here
    res.status(501).json({ error: "Real OAuth not implemented yet" });
  });

  app.get("/api/auth/mock-success", async (req, res) => {
    const provider = req.query.provider as string || "unknown";
    
    try {
      // Create/get demo OAuth user
      const mockEmail = `demo-${provider.toLowerCase()}@ybuilt.com`;
      let user = await storage.getUserByEmail(mockEmail);
      
      if (!user) {
        user = await storage.createUser({
          email: mockEmail,
          username: `${provider}User`,
          password: "oauth-mock-password"
        });
        logger.info(`Mock OAuth: Auto-created ${provider} user`);
      }

      // In a real app, you'd set a secure session cookie here
      // For now, just redirect to homepage with success param
      res.redirect(`/?oauth=success&provider=${provider}&email=${encodeURIComponent(mockEmail)}`);
    } catch (error) {
      logger.error({ error }, "OAuth mock error");
      res.redirect(`/?oauth=error`);
    }
  });

  // Settings API
  app.get("/api/settings", async (req, res) => {
    try {
      // In mock mode, use demo user ID from authorization or default
      const userId = "demo"; // In production, extract from JWT
      const settings = await storage.getSettings(userId);
      res.json(settings);
    } catch (error) {
      logger.error({ error }, "Error fetching settings");
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.patch("/api/settings/:section", async (req, res) => {
    try {
      const { section } = req.params;
      const userId = "demo"; // In production, extract from JWT
      
      // Validate section is a valid settings section
      const validSections = ["appearance", "account", "workspace", "editor", "ai", "organization", "security", "integrations", "billing", "team", "notifications", "export"];
      if (!validSections.includes(section)) {
        return res.status(400).json({ error: "Invalid settings section" });
      }
      
      // Get current settings
      const current = await storage.getSettings(userId);
      
      // Validate the section data against the schema
      const { settingsSchema } = await import("@shared/schema");
      const sectionSchema = settingsSchema.shape[section as keyof typeof settingsSchema.shape];
      
      // Parse and validate the incoming section data
      const validatedSectionData = sectionSchema.parse(req.body);
      
      // Update only the specific section
      const updates = { [section]: validatedSectionData };
      const updatedSettings = await storage.updateSettings(userId, updates);
      
      res.json(updatedSettings);
    } catch (error) {
      logger.error({ error }, "Error updating settings");
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid settings data", details: error });
      }
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // ===== NEW WORKSPACE & PUBLISH ROUTES =====

  // Get plan info
  app.get("/api/plan", async (req, res) => {
    try {
      // In mock mode, use demo user
      const userId = "demo";
      const credits = await storage.getUserCredits(userId);

      res.json({
        currentPlan: "free",
        publishCost: 50, // INR per publish
        credits
      });
    } catch (error) {
      logger.error({ error }, "Error fetching plan");
      res.status(500).json({ error: "Failed to fetch plan" });
    }
  });

  // Create Razorpay order for credits purchase
  app.post("/api/create_order", async (req, res) => {
    try {
      const { amount } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ error: "Invalid amount" });
      }

      // In mock mode, return a mock order
      const orderId = `order_${crypto.randomUUID().slice(0, 12)}`;
      
      res.json({
        id: orderId,
        amount: amount * 100, // Razorpay expects amount in paise
        currency: "INR",
        receipt: `receipt_${Date.now()}`,
        status: "created"
      });
    } catch (error) {
      logger.error({ error }, "Error creating order");
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  // Verify payment and add credits
  app.post("/api/verify_payment", async (req, res) => {
    try {
      const { orderId, paymentId, amount } = req.body;
      const userId = "demo"; // In production, extract from JWT

      // In mock mode, just add credits
      await storage.addCredits(userId, amount);

      // Create invoice for credit purchase
      const invoice = {
        id: `inv_${crypto.randomUUID().slice(0, 8)}`,
        userId,
        amount,
        type: "credit_purchase" as const,
        jobId: null,
        timestamp: new Date().toISOString(),
        status: "paid" as const,
        paymentId,
        orderId
      };

      await storage.createInvoice(invoice);

      res.json({
        success: true,
        credits: await storage.getUserCredits(userId)
      });
    } catch (error) {
      logger.error({ error }, "Error verifying payment");
      res.status(500).json({ error: "Failed to verify payment" });
    }
  });

  // Publish job
  app.post("/api/jobs/:jobId/publish", async (req, res) => {
    try {
      const { jobId } = req.params;
      const userId = "demo"; // In production, extract from JWT

      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      // Check credits
      const publishCost = 50;
      const credits = await storage.getUserCredits(userId);

      if (credits < publishCost) {
        return res.status(402).json({ 
          error: "Insufficient credits", 
          required: publishCost,
          available: credits 
        });
      }

      // Deduct credits
      await storage.deductCredits(userId, publishCost);

      // Create invoice
      const invoice = {
        id: `inv_${crypto.randomUUID().slice(0, 8)}`,
        userId,
        amount: publishCost,
        type: "publish" as const,
        jobId,
        timestamp: new Date().toISOString(),
        status: "paid" as const
      };

      await storage.createInvoice(invoice);

      // Update job status
      await storage.updateJob(jobId, { status: "published" });

      const publishedUrl = `https://${jobId}.ybuilt.app`;

      res.json({
        success: true,
        publishedUrl,
        invoice
      });
    } catch (error) {
      logger.error({ error }, "Error publishing job");
      res.status(500).json({ error: "Failed to publish" });
    }
  });

  // Get workspace file
  app.get("/api/workspace/:jobId/file", async (req, res) => {
    try {
      const { jobId } = req.params;
      const { path: filePath } = req.query;

      // Security: Validate jobId
      const jobIdValidation = validateJobId(jobId);
      if (!jobIdValidation.valid) {
        return res.status(400).json({ error: jobIdValidation.error });
      }

      if (!filePath || typeof filePath !== "string") {
        return res.status(400).json({ error: "Missing file path" });
      }

      const workspaceDir = path.join(process.cwd(), "public", "previews", jobId);
      
      // Security: Validate and resolve path
      try {
        const resolvedPath = await validateAndResolvePath(workspaceDir, filePath);
        const content = await fs.readFile(resolvedPath, "utf-8");
        res.json({ path: filePath, content });
      } catch (err: any) {
        if (err.code === 400) {
          return res.status(400).json({ error: err.message });
        }
        if (err.code === 403) {
          return res.status(403).json({ error: err.message });
        }
        if (err.code === 'ENOENT') {
          return res.status(404).json({ error: "File not found" });
        }
        // Unexpected error
        logger.error({ error: err }, 'Unexpected path validation error');
        return res.status(500).json({ error: 'Internal server error' });
      }
    } catch (error) {
      logger.error({ error }, "Error reading file");
      res.status(500).json({ error: "Failed to read file" });
    }
  });

  // Save workspace file (POST - for backward compatibility)
  app.post("/api/workspace/:jobId/file", async (req, res) => {
    try {
      const { jobId } = req.params;
      const { path: filePath, content } = req.body;

      // Security: Validate jobId
      const jobIdValidation = validateJobId(jobId);
      if (!jobIdValidation.valid) {
        return res.status(400).json({ error: jobIdValidation.error });
      }

      if (!filePath || typeof content !== "string") {
        return res.status(400).json({ error: "Missing file path or content" });
      }

      const workspaceDir = path.join(process.cwd(), "public", "previews", jobId);
      
      // Security: Validate and resolve path
      try {
        const resolvedPath = await validateAndResolvePath(workspaceDir, filePath);
        const dirPath = path.dirname(resolvedPath);
        
        // Ensure directory exists
        await fs.mkdir(dirPath, { recursive: true });

        // Write file
        await fs.writeFile(resolvedPath, content, "utf-8");

        res.json({ success: true, path: filePath });
      } catch (err: any) {
        if (err.code === 400) {
          return res.status(400).json({ error: err.message });
        }
        if (err.code === 403) {
          return res.status(403).json({ error: err.message });
        }
        // Unexpected error
        logger.error({ error: err }, 'Unexpected path validation error');
        return res.status(500).json({ error: 'Internal server error' });
      }
    } catch (error) {
      logger.error({ error }, "Error writing file");
      res.status(500).json({ error: "Failed to write file" });
    }
  });

  // Update workspace file (PUT - used by Page Tool)
  app.put("/api/workspace/:jobId/files/:filePath(*)", async (req, res) => {
    try {
      const { jobId, filePath } = req.params;
      const { content } = req.body;

      // Security: Validate jobId
      const jobIdValidation = validateJobId(jobId);
      if (!jobIdValidation.valid) {
        return res.status(400).json({ error: jobIdValidation.error });
      }

      if (!filePath || typeof content !== "string") {
        return res.status(400).json({ error: "Missing file path or content" });
      }

      const workspaceDir = path.join(process.cwd(), "public", "previews", jobId);
      
      // Security: Validate and resolve path
      try {
        const resolvedPath = await validateAndResolvePath(workspaceDir, filePath);
        const dirPath = path.dirname(resolvedPath);

        // Ensure directory exists
        await fs.mkdir(dirPath, { recursive: true });

        // Write file
        await fs.writeFile(resolvedPath, content, "utf-8");

        // Log for debugging
        const auditLog = `${new Date().toISOString()} - Updated file: ${filePath}, Job: ${jobId}\n`;
        await fs.appendFile(
          path.join(process.cwd(), "data", "audit.log"),
          auditLog
        ).catch(() => {});

        res.json({ success: true, path: filePath });
      } catch (err: any) {
        if (err.code === 400) {
          return res.status(400).json({ error: err.message });
        }
        if (err.code === 403) {
          return res.status(403).json({ error: err.message });
        }
        // Unexpected error
        logger.error({ error: err }, 'Unexpected path validation error');
        return res.status(500).json({ error: 'Internal server error' });
      }
    } catch (error) {
      logger.error({ error }, "Error updating file");
      res.status(500).json({ error: "Failed to update file" });
    }
  });

  // Prompt to file - convert prompt text to file
  app.post("/api/workspace/:jobId/prompt-to-file", async (req, res) => {
    try {
      const { jobId } = req.params;
      const { promptText, filenameHint } = req.body;

      if (!promptText) {
        return res.status(400).json({ error: "Missing prompt text" });
      }

      const ts = Date.now();
      const safeName = (filenameHint || `prompt-${ts}`).replace(/[^a-z0-9._-]/gi, '-').slice(0, 80);
      const promptsDir = path.join(process.cwd(), "data", "workspaces", jobId, "prompts");
      
      // Ensure prompts directory exists
      await fs.mkdir(promptsDir, { recursive: true });

      const fileName = `${safeName}.md`;
      const filePath = path.join(promptsDir, fileName);

      // Write prompt as markdown file
      const content = `# Prompt\n\n${promptText}\n\n---\n\n*Created: ${new Date().toISOString()}*`;
      await fs.writeFile(filePath, content, "utf-8");

      // Log for debugging
      const auditLog = `${new Date().toISOString()} - Prompt to file: ${fileName}, Job: ${jobId}\n`;
      await fs.appendFile(
        path.join(process.cwd(), "data", "audit.log"),
        auditLog
      ).catch(() => {}); // Ignore errors for audit log

      const file = {
        path: `prompts/${fileName}`,
        name: fileName,
        url: `/workspaces/${jobId}/prompts/${fileName}`,
        size: content.length,
        type: 'prompt'
      };

      res.json({ file, fileCreated: true });
    } catch (error) {
      logger.error({ error }, "Error creating prompt file");
      res.status(500).json({ error: "Failed to create prompt file" });
    }
  });

  // Create folder in workspace
  app.post("/api/workspace/:jobId/folder", async (req, res) => {
    try {
      const { jobId } = req.params;
      const { path: folderPath } = req.body;

      if (!folderPath || typeof folderPath !== "string") {
        return res.status(400).json({ error: "Missing folder path" });
      }

      // Sanitize folder path
      const safePath = folderPath.replace(/[^a-z0-9/_-]/gi, '-');
      const fullPath = path.join(process.cwd(), "data", "workspaces", jobId, safePath);

      // Create folder
      await fs.mkdir(fullPath, { recursive: true });

      // Log for debugging
      const auditLog = `${new Date().toISOString()} - New folder: ${safePath}, Job: ${jobId}\n`;
      await fs.appendFile(
        path.join(process.cwd(), "data", "audit.log"),
        auditLog
      ).catch(() => {}); // Ignore errors for audit log

      res.json({ ok: true, path: safePath });
    } catch (error) {
      logger.error({ error }, "Error creating folder");
      res.status(500).json({ error: "Failed to create folder" });
    }
  });

  // Delete workspace file
  app.delete("/api/workspace/:jobId/file", async (req, res) => {
    try {
      const { jobId } = req.params;
      const { path: filePath } = req.query;

      // Security: Validate jobId
      const jobIdValidation = validateJobId(jobId);
      if (!jobIdValidation.valid) {
        return res.status(400).json({ error: jobIdValidation.error });
      }

      if (!filePath || typeof filePath !== "string") {
        return res.status(400).json({ error: "Missing file path" });
      }

      // Determine if it's a prompt file or regular file
      const isPromptFile = filePath.startsWith("prompts/");
      const workspaceDir = isPromptFile
        ? path.join(process.cwd(), "data", "workspaces", jobId)
        : path.join(process.cwd(), "public", "previews", jobId);

      // For prompt files, remove the prompts/ prefix before validation
      const pathToValidate = isPromptFile ? filePath.replace(/^prompts\//, '') : filePath;
      
      // Security: Validate and resolve path
      try {
        const resolvedPath = await validateAndResolvePath(workspaceDir, pathToValidate);
        
        // Security: Prevent deletion of protected files using resolved paths
        if (isProtectedFile(resolvedPath, workspaceDir)) {
          return res.status(403).json({ error: "Cannot delete protected file" });
        }

        await fs.unlink(resolvedPath);
        
        // Log deletion
        const auditLog = `${new Date().toISOString()} - Deleted file: ${filePath}, Job: ${jobId}\n`;
        await fs.appendFile(
          path.join(process.cwd(), "data", "audit.log"),
          auditLog
        ).catch(() => {});

        res.json({ success: true, path: filePath });
      } catch (err: any) {
        if (err.code === 400) {
          return res.status(400).json({ error: err.message });
        }
        if (err.code === 403) {
          return res.status(403).json({ error: err.message });
        }
        if (err.code === 'ENOENT') {
          return res.status(404).json({ error: "File not found" });
        }
        // Unexpected error
        logger.error({ error: err }, 'Unexpected path validation error');
        return res.status(500).json({ error: 'Internal server error' });
      }
    } catch (error) {
      logger.error({ error }, "Error deleting file");
      res.status(500).json({ error: "Failed to delete file" });
    }
  });

  // Upload asset files to workspace
  app.post("/api/workspace/:jobId/upload", upload.single("file"), async (req, res) => {
    try {
      const { jobId } = req.params;

      // Security: Validate jobId
      const jobIdValidation = validateJobId(jobId);
      if (!jobIdValidation.valid) {
        return res.status(400).json({ error: jobIdValidation.error });
      }

      const uploadedFile = req.file;

      if (!uploadedFile) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      // Security: Sanitize filename - remove path traversal and dangerous characters
      const sanitizedFilename = uploadedFile.originalname
        .replace(/\.\./g, '')
        .replace(/[/\\]/g, '')
        .replace(/^\.+/, '')
        .replace(/[<>:"|?*]/g, '') // Remove special characters
        .slice(0, 255); // Limit length

      if (!sanitizedFilename) {
        return res.status(400).json({ error: "Invalid filename" });
      }

      // Create destination directory for user uploads
      const userId = "demo"; // In production, extract from JWT
      const uploadsDir = path.join(process.cwd(), "public", "uploads", userId, jobId);
      await fs.mkdir(uploadsDir, { recursive: true });

      // Security: Validate and resolve path (using normalized sanitized filename)
      try {
        const resolvedPath = await validateAndResolvePath(uploadsDir, sanitizedFilename);

        await fs.rename(uploadedFile.path, resolvedPath);

        const publicUrl = `/uploads/${userId}/${jobId}/${sanitizedFilename}`;

        // Add to storage for tracking
        await storage.addUploadedAsset(jobId, {
          url: publicUrl,
          name: sanitizedFilename,
          mime: uploadedFile.mimetype,
          size: uploadedFile.size
        });

        // Log upload
        const auditLog = `${new Date().toISOString()} - Uploaded: ${sanitizedFilename} (original: ${uploadedFile.originalname}), Job: ${jobId}, Size: ${uploadedFile.size}\n`;
        await fs.appendFile(
          path.join(process.cwd(), "data", "audit.log"),
          auditLog
        ).catch(() => {});

        res.json({
          success: true,
          file: {
            id: crypto.randomUUID(),
            filename: sanitizedFilename,
            url: publicUrl,
            size: uploadedFile.size,
            type: uploadedFile.mimetype
          }
        });
      } catch (err: any) {
        if (err.code === 400) {
          return res.status(400).json({ error: err.message });
        }
        if (err.code === 403) {
          return res.status(403).json({ error: err.message });
        }
        // Unexpected error
        logger.error({ error: err }, 'Unexpected path validation error');
        return res.status(500).json({ error: 'Internal server error' });
      }
    } catch (error) {
      logger.error({ error }, "Error uploading file");
      res.status(500).json({ error: "Failed to upload file" });
    }
  });

  // Process manager - track running dev processes
  const runningProcesses = new Map<string, {
    processId: string;
    jobId: string;
    port: number;
    startedAt: string;
    logInterval?: NodeJS.Timeout;
  }>();

  // Start dev process
  app.post("/api/workspace/:jobId/run", async (req, res) => {
    try {
      const { jobId } = req.params;

      // Check if process already running
      if (runningProcesses.has(jobId)) {
        const existing = runningProcesses.get(jobId)!;
        return res.json({
          processId: existing.processId,
          port: existing.port,
          status: "already_running"
        });
      }

      const processId = `proc_${crypto.randomUUID().slice(0, 12)}`;
      const port = 3000 + Math.floor(Math.random() * 1000); // Random port 3000-4000

      // Create process entry
      const process = {
        processId,
        jobId,
        port,
        startedAt: new Date().toISOString()
      };

      runningProcesses.set(jobId, process);

      // Simulate dev server logs
      const logFile = path.join(globalThis.process.cwd(), "data", "jobs", jobId, "logs.jsonl");
      await fs.mkdir(path.dirname(logFile), { recursive: true });

      // Write initial log
      const initLog = {
        timestamp: new Date().toISOString(),
        level: "info",
        source: "express",
        message: `Dev server starting on port ${port}...`,
        metadata: { processId, port }
      };
      await fs.appendFile(logFile, JSON.stringify(initLog) + "\n");

      // Simulate periodic logs
      const logInterval = setInterval(async () => {
        const logs = [
          { level: "info", message: `[express] GET / 200 in ${Math.floor(Math.random() * 50)}ms` },
          { level: "info", message: `[vite] hmr update ${Date.now()}` },
          { level: "info", message: `[express] GET /api/status 304 in ${Math.floor(Math.random() * 10)}ms` }
        ];

        const randomLog = logs[Math.floor(Math.random() * logs.length)];
        const log = {
          timestamp: new Date().toISOString(),
          level: randomLog.level,
          source: "express",
          message: randomLog.message,
          metadata: { processId }
        };

        try {
          await fs.appendFile(logFile, JSON.stringify(log) + "\n");
        } catch (error) {
          logger.error({ error }, "Error writing process log");
        }
      }, 3000 + Math.random() * 2000); // Random interval 3-5 seconds

      // Update process with logInterval
      runningProcesses.set(jobId, { ...process, logInterval });

      // Write started log
      const startedLog = {
        timestamp: new Date().toISOString(),
        level: "info",
        source: "express",
        message: `serving on port ${port}`,
        metadata: { processId, port }
      };
      await fs.appendFile(logFile, JSON.stringify(startedLog) + "\n");

      res.json({ processId, port, status: "started" });
    } catch (error) {
      logger.error({ error }, "Error starting process");
      res.status(500).json({ error: "Failed to start process" });
    }
  });

  // Stop dev process
  app.post("/api/workspace/:jobId/stop", async (req, res) => {
    try {
      const { jobId } = req.params;

      const process = runningProcesses.get(jobId);
      if (!process) {
        return res.status(404).json({ error: "Process not found" });
      }

      // Clear log interval
      if (process.logInterval) {
        clearInterval(process.logInterval);
      }

      // Write stopped log
      const logFile = path.join(globalThis.process.cwd(), "data", "jobs", jobId, "logs.jsonl");
      const stoppedLog = {
        timestamp: new Date().toISOString(),
        level: "info",
        source: "express",
        message: "Dev server stopped",
        metadata: { processId: process.processId }
      };
      await fs.appendFile(logFile, JSON.stringify(stoppedLog) + "\n");

      runningProcesses.delete(jobId);

      res.json({ success: true, processId: process.processId });
    } catch (error) {
      logger.error({ error }, "Error stopping process");
      res.status(500).json({ error: "Failed to stop process" });
    }
  });

  // List running processes
  app.get("/api/workspace/:jobId/processes", async (req, res) => {
    try {
      const { jobId } = req.params;

      const process = runningProcesses.get(jobId);
      if (!process) {
        return res.json({ processes: [] });
      }

      res.json({
        processes: [{
          processId: process.processId,
          port: process.port,
          startedAt: process.startedAt,
          status: "running"
        }]
      });
    } catch (error) {
      logger.error({ error }, "Error listing processes");
      res.status(500).json({ error: "Failed to list processes" });
    }
  });

  // Log streaming (SSE)
  app.get("/api/jobs/:jobId/logs/stream", async (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no"); // Disable nginx buffering

    const { jobId } = req.params;
    const logFile = path.join(process.cwd(), "data", "jobs", jobId, "logs.jsonl");

    // Send initial connection message
    res.write(`data: ${JSON.stringify({ type: "connected", jobId })}\n\n`);

    // Send existing logs first
    try {
      const content = await fs.readFile(logFile, "utf-8");
      const existingLogs = content.trim().split("\n").filter(Boolean);
      
      for (const line of existingLogs) {
        try {
          const log = JSON.parse(line);
          // Transform to expected format
          const transformedLog = {
            timestamp: log.timestamp || new Date(log.ts || Date.now()).toISOString(),
            level: log.level || "info",
            source: log.source || "worker",
            message: log.message || log.msg || "",
            metadata: log.metadata || log.details || log.meta || {}
          };
          res.write(`data: ${JSON.stringify(transformedLog)}\n\n`);
        } catch (parseError) {
          logger.error({ error: parseError }, "Failed to parse log line");
        }
      }
    } catch (error) {
      // No logs yet or file doesn't exist
      logger.info(`No logs found for job ${jobId}`);
    }

    // Poll for new logs every 500ms
    let lastSize = 0;
    try {
      const stats = await fs.stat(logFile);
      lastSize = stats.size;
    } catch (error) {
      // File doesn't exist yet
    }

    const intervalId = setInterval(async () => {
      try {
        const stats = await fs.stat(logFile);
        if (stats.size > lastSize) {
          // File has grown, read new content
          const stream = await fs.open(logFile, "r");
          const buffer = Buffer.alloc(stats.size - lastSize);
          await stream.read(buffer, 0, buffer.length, lastSize);
          await stream.close();
          
          const newContent = buffer.toString("utf-8");
          const newLines = newContent.trim().split("\n").filter(Boolean);
          
          for (const line of newLines) {
            try {
              const log = JSON.parse(line);
              const transformedLog = {
                timestamp: log.timestamp || new Date(log.ts || Date.now()).toISOString(),
                level: log.level || "info",
                source: log.source || "worker",
                message: log.message || log.msg || "",
                metadata: log.metadata || log.details || log.meta || {}
              };
              res.write(`data: ${JSON.stringify(transformedLog)}\n\n`);
            } catch (parseError) {
              logger.error({ error: parseError }, "Failed to parse log line");
            }
          }
          
          lastSize = stats.size;
        }
      } catch (error) {
        // File doesn't exist yet, that's ok
      }
    }, 500);

    // Clean up on client disconnect
    req.on("close", () => {
      clearInterval(intervalId);
      res.end();
    });
  });

  // Build job
  app.post("/api/jobs/:jobId/build", async (req, res) => {
    try {
      const { jobId } = req.params;
      const { autonomy, autoApply, safetyFilter, computeTier, prompt } = req.body;

      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      // Collect all agent settings
      const agentSettings = {
        autonomy: autonomy || "medium",
        autoApply: autoApply ?? false,
        safetyFilter: safetyFilter ?? true,
        computeTier: computeTier || "standard"
      };

      // Update job with full agent settings
      await storage.updateJob(jobId, { 
        status: "queued",
        settings: JSON.stringify({ agentSettings })
      });

      // Trigger job queue with agent settings
      const buildPrompt = prompt || job.prompt || "Rebuild and refine the application";
      await jobQueue.addJob(jobId, buildPrompt, undefined, agentSettings.autonomy);

      res.json({ 
        success: true, 
        status: "queued",
        agentSettings
      });
    } catch (error) {
      logger.error({ error }, "Error starting build");
      res.status(500).json({ error: "Failed to start build" });
    }
  });

  // Extensions list
  app.get("/api/extensions", async (req, res) => {
    try {
      res.json([
        { id: "prettier", name: "Prettier", icon: "✨", installed: true },
        { id: "eslint", name: "ESLint", icon: "🔍", installed: false },
        { id: "typescript", name: "TypeScript", icon: "📘", installed: true },
        { id: "tailwind", name: "Tailwind IntelliSense", icon: "🎨", installed: true },
      ]);
    } catch (error) {
      logger.error({ error }, "Error fetching extensions");
      res.status(500).json({ error: "Failed to fetch extensions" });
    }
  });

  // Command palette search
  app.post("/api/search/palette", async (req, res) => {
    try {
      const { query } = req.body;
      
      // Mock implementation - return filtered results
      const allCommands = [
        { id: "new-file", label: "New File", category: "Files" },
        { id: "upload", label: "Upload", category: "Files" },
        { id: "preview", label: "Preview", category: "Actions" },
        { id: "console", label: "Console", category: "Actions" },
        { id: "settings", label: "Settings", category: "Tools" },
      ];

      const filtered = query 
        ? allCommands.filter(cmd => 
            cmd.label.toLowerCase().includes(query.toLowerCase())
          )
        : allCommands;

      res.json(filtered);
    } catch (error) {
      logger.error({ error }, "Error searching commands");
      res.status(500).json({ error: "Failed to search commands" });
    }
  });

  // ========== PROFILE ENDPOINTS ==========
  
  // GET /api/users/:userId/profile - Get user profile and projects
  app.get("/api/users/:userId/profile", async (req, res) => {
    try {
      const { userId } = req.params;
      const profileData = await storage.getUserProfile(userId);
      res.json(profileData);
    } catch (error: any) {
      logger.error({ error }, "Error fetching profile");
      if (error.message === "User not found") {
        return res.status(404).json({ error: "User not found" });
      }
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  // POST /api/users/:userId/profile - Update user profile
  app.post("/api/users/:userId/profile", async (req, res) => {
    try {
      const { userId } = req.params;
      const { firstName, lastName, bio, publicProfile } = req.body;
      
      const updatedUser = await storage.updateUserProfile(userId, {
        firstName,
        lastName,
        bio,
        publicProfile,
      });
      
      res.json(updatedUser);
    } catch (error: any) {
      logger.error({ error }, "Error updating profile");
      if (error.message === "User not found") {
        return res.status(404).json({ error: "User not found" });
      }
      if (error.message?.includes("Bio must be")) {
        return res.status(400).json({ error: error.message });
      }
      res.status(500).json({ error: "Failed to update profile" });
    }
  });


  // POST /api/users/:userId/projects/:projectId/export - Export project as zip
  app.post("/api/users/:userId/projects/:projectId/export", async (req, res) => {
    try {
      const { userId, projectId } = req.params;
      
      const job = await storage.getJob(projectId);
      if (!job) {
        return res.status(404).json({ error: "Project not found" });
      }

      if (job.userId !== userId) {
        return res.status(403).json({ error: "Unauthorized" });
      }

      const exportsDir = path.join(process.cwd(), "public", "exports", userId);
      await fs.mkdir(exportsDir, { recursive: true });
      
      const zipPath = path.join(exportsDir, `${projectId}.zip`);
      const output = await fs.open(zipPath, "w");
      const archive = archiver("zip", { zlib: { level: 9 } });

      archive.pipe(output.createWriteStream());

      // Add project files
      const previewDir = path.join(process.cwd(), "public", "previews", projectId);
      try {
        await fs.access(previewDir);
        archive.directory(previewDir, false);
      } catch (error) {
        // No preview files, just add a README
        archive.append("This project has no files yet.", { name: "README.txt" });
      }

      await archive.finalize();
      await output.close();

      const downloadUrl = `/exports/${userId}/${projectId}.zip`;
      res.json({ downloadUrl });
    } catch (error) {
      logger.error({ error }, "Error exporting project");
      res.status(500).json({ error: "Failed to export project" });
    }
  });

  // ========== ACCOUNT ENDPOINTS ==========
  
  // POST /api/users/:userId/email/change - Change email (mock)
  app.post("/api/users/:userId/email/change", async (req, res) => {
    try {
      const { userId } = req.params;
      const { newEmail } = req.body;
      
      if (!newEmail || !z.string().email().safeParse(newEmail).success) {
        return res.status(400).json({ error: "Invalid email address" });
      }

      // Mock verification flow - in production would send verification email
      res.json({ 
        success: true, 
        message: "Verification email sent to " + newEmail 
      });
    } catch (error) {
      logger.error({ error }, "Error changing email");
      res.status(500).json({ error: "Failed to change email" });
    }
  });

  // POST /api/users/:userId/password/change - Change password
  app.post("/api/users/:userId/password/change", async (req, res) => {
    try {
      const { userId } = req.params;
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ error: "Current and new password required" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Validate current password
      if (user.password !== currentPassword) {
        return res.status(400).json({ error: "Current password is incorrect" });
      }

      // Update password (in production would hash with bcrypt)
      await storage.updateUser(userId, { password: newPassword });

      res.json({ success: true, message: "Password updated successfully" });
    } catch (error) {
      logger.error({ error }, "Error changing password");
      res.status(500).json({ error: "Failed to change password" });
    }
  });

  // PATCH /api/users/:userId/region - Update user region
  app.patch("/api/users/:userId/region", async (req, res) => {
    try {
      const { userId } = req.params;
      const { region } = req.body;
      
      if (!region) {
        return res.status(400).json({ error: "Region is required" });
      }

      const updatedUser = await storage.updateUser(userId, { region });
      res.json(updatedUser);
    } catch (error) {
      logger.error({ error }, "Error updating region");
      res.status(500).json({ error: "Failed to update region" });
    }
  });

  // PATCH /api/users/:userId/notifications - Update notification settings
  app.patch("/api/users/:userId/notifications", async (req, res) => {
    try {
      const { userId } = req.params;
      const { notificationSettings } = req.body;
      
      if (!notificationSettings) {
        return res.status(400).json({ error: "Notification settings required" });
      }

      const updatedUser = await storage.updateUser(userId, { notificationSettings });
      res.json(updatedUser);
    } catch (error) {
      logger.error({ error }, "Error updating notifications");
      res.status(500).json({ error: "Failed to update notifications" });
    }
  });

  // POST /api/users/:userId/notifications/test - Test notification
  app.post("/api/users/:userId/notifications/test", async (req, res) => {
    try {
      const { userId } = req.params;
      const { channel, eventType } = req.body;
      
      if (!channel || !eventType) {
        return res.status(400).json({ error: "Channel and eventType are required" });
      }

      // Mock notification test - in production would send actual notification
      res.json({ 
        success: true, 
        message: `Test notification sent to ${channel} for ${eventType}`,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      logger.error({ error }, "Error sending test notification");
      res.status(500).json({ error: "Failed to send test notification" });
    }
  });

  // POST /api/users/:userId/export-apps - Export all user projects
  app.post("/api/users/:userId/export-apps", async (req, res) => {
    try {
      const { userId } = req.params;
      
      const exportsDir = path.join(process.cwd(), "public", "exports", userId);
      await fs.mkdir(exportsDir, { recursive: true });
      
      const zipPath = path.join(exportsDir, "all-projects.zip");
      const output = await fs.open(zipPath, "w");
      const archive = archiver("zip", { zlib: { level: 9 } });

      archive.pipe(output.createWriteStream());

      const jobs = await storage.getUserJobs(userId);
      
      for (const job of jobs) {
        const previewDir = path.join(process.cwd(), "public", "previews", job.id);
        try {
          await fs.access(previewDir);
          archive.directory(previewDir, `project-${job.id}`);
        } catch (error) {
          // Skip if no preview files
        }
      }

      await archive.finalize();
      await output.close();

      const downloadUrl = `/exports/${userId}/all-projects.zip`;
      res.json({ downloadUrl, status: "ready" });
    } catch (error) {
      logger.error({ error }, "Error exporting all apps");
      res.status(500).json({ error: "Failed to export apps" });
    }
  });

  // GET /api/users/:userId/billing - Get billing info
  app.get("/api/users/:userId/billing", async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Mock billing data
      const billingData = {
        plan: "Creator Plan",
        nextPayment: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        amount: 2000,
        currency: "INR",
        paymentMethod: {
          type: "card",
          last4: "4242",
        },
        usage: {
          builds: 42,
          storage: 1250,
          bandwidth: 8500,
        },
        limits: {
          builds: 1000,
          storage: 10000,
          bandwidth: 50000,
        },
      };

      res.json(billingData);
    } catch (error) {
      logger.error({ error }, "Error fetching billing");
      res.status(500).json({ error: "Failed to fetch billing info" });
    }
  });

  // POST /api/users/:userId/usage-alerts - Set usage alert threshold
  app.post("/api/users/:userId/usage-alerts", async (req, res) => {
    try {
      const { userId } = req.params;
      const { threshold } = req.body;
      
      if (typeof threshold !== "number" || threshold < 0 || threshold > 100) {
        return res.status(400).json({ error: "Threshold must be between 0 and 100" });
      }

      // Mock storage - in production would save to user settings
      res.json({ success: true, threshold });
    } catch (error) {
      logger.error({ error }, "Error setting usage alert");
      res.status(500).json({ error: "Failed to set usage alert" });
    }
  });

  // POST /api/users/:userId/roles - Update user roles
  app.post("/api/users/:userId/roles", async (req, res) => {
    try {
      const { userId } = req.params;
      const { roles } = req.body;
      
      if (!Array.isArray(roles)) {
        return res.status(400).json({ error: "Roles must be an array" });
      }

      const updatedUser = await storage.updateUser(userId, { roles });
      res.json(updatedUser);
    } catch (error) {
      logger.error({ error }, "Error updating roles");
      res.status(500).json({ error: "Failed to update roles" });
    }
  });

  // ========== SSH KEYS ENDPOINTS ==========
  
  // GET /api/users/:userId/ssh-keys - Get SSH keys
  app.get("/api/users/:userId/ssh-keys", async (req, res) => {
    try {
      const { userId } = req.params;
      const keys = await storage.getUserSSHKeys(userId);
      res.json(keys);
    } catch (error) {
      logger.error({ error }, "Error fetching SSH keys");
      res.status(500).json({ error: "Failed to fetch SSH keys" });
    }
  });

  // POST /api/users/:userId/ssh-keys - Add SSH key
  app.post("/api/users/:userId/ssh-keys", async (req, res) => {
    try {
      const { userId } = req.params;
      const { name, publicKey } = req.body;
      
      if (!name || !publicKey) {
        return res.status(400).json({ error: "Name and public key required" });
      }

      // Basic SSH key validation
      if (!publicKey.startsWith("ssh-rsa") && !publicKey.startsWith("ssh-ed25519")) {
        return res.status(400).json({ error: "Invalid SSH key format" });
      }

      const newKey = await storage.addSSHKey(userId, { name, publicKey });
      res.json(newKey);
    } catch (error) {
      logger.error({ error }, "Error adding SSH key");
      res.status(500).json({ error: "Failed to add SSH key" });
    }
  });

  // DELETE /api/users/:userId/ssh-keys/:keyId - Delete SSH key
  app.delete("/api/users/:userId/ssh-keys/:keyId", async (req, res) => {
    try {
      const { userId, keyId } = req.params;
      await storage.deleteSSHKey(userId, keyId);
      res.json({ success: true });
    } catch (error) {
      logger.error({ error }, "Error deleting SSH key");
      res.status(500).json({ error: "Failed to delete SSH key" });
    }
  });

  // ========== SECRETS ENDPOINTS ==========
  
  // GET /api/users/:userId/secrets - Get secrets
  app.get("/api/users/:userId/secrets", async (req, res) => {
    try {
      const { userId } = req.params;
      const secrets = await storage.getUserSecrets(userId);
      res.json(secrets);
    } catch (error) {
      logger.error({ error }, "Error fetching secrets");
      res.status(500).json({ error: "Failed to fetch secrets" });
    }
  });

  // POST /api/users/:userId/secrets - Add secret
  app.post("/api/users/:userId/secrets", async (req, res) => {
    try {
      const { userId } = req.params;
      const { name, value } = req.body;
      
      if (!name || !value) {
        return res.status(400).json({ error: "Name and value required" });
      }

      const newSecret = await storage.addSecret(userId, { name, value });
      res.json(newSecret);
    } catch (error) {
      logger.error({ error }, "Error adding secret");
      res.status(500).json({ error: "Failed to add secret" });
    }
  });

  // DELETE /api/users/:userId/secrets/:name - Delete secret
  app.delete("/api/users/:userId/secrets/:name", async (req, res) => {
    try {
      const { userId, name } = req.params;
      await storage.deleteSecret(userId, name);
      res.json({ success: true });
    } catch (error) {
      logger.error({ error }, "Error deleting secret");
      res.status(500).json({ error: "Failed to delete secret" });
    }
  });

  // ========== INTEGRATIONS ENDPOINTS ==========
  
  // GET /api/users/:userId/integrations - Get integrations
  app.get("/api/users/:userId/integrations", async (req, res) => {
    try {
      const { userId } = req.params;
      const integrations = await storage.getUserIntegrations(userId);
      res.json(integrations);
    } catch (error) {
      logger.error({ error }, "Error fetching integrations");
      res.status(500).json({ error: "Failed to fetch integrations" });
    }
  });

  // POST /api/users/:userId/integrations/:provider/connect - Connect integration
  app.post("/api/users/:userId/integrations/:provider/connect", async (req, res) => {
    try {
      const { userId, provider } = req.params;
      await storage.connectIntegration(userId, provider);
      res.json({ success: true, message: `Connected to ${provider}` });
    } catch (error) {
      logger.error({ error }, "Error connecting integration");
      res.status(500).json({ error: "Failed to connect integration" });
    }
  });

  // POST /api/users/:userId/integrations/:provider/disconnect - Disconnect integration
  app.post("/api/users/:userId/integrations/:provider/disconnect", async (req, res) => {
    try {
      const { userId, provider } = req.params;
      await storage.disconnectIntegration(userId, provider);
      res.json({ success: true, message: `Disconnected from ${provider}` });
    } catch (error) {
      logger.error({ error }, "Error disconnecting integration");
      res.status(500).json({ error: "Failed to disconnect integration" });
    }
  });

  // ========== DOMAINS ENDPOINTS ==========
  
  // GET /api/users/:userId/domains - Get domains
  app.get("/api/users/:userId/domains", async (req, res) => {
    try {
      const { userId } = req.params;
      const domains = await storage.getUserDomains(userId);
      res.json(domains);
    } catch (error) {
      logger.error({ error }, "Error fetching domains");
      res.status(500).json({ error: "Failed to fetch domains" });
    }
  });

  // POST /api/users/:userId/domains - Add domain
  app.post("/api/users/:userId/domains", async (req, res) => {
    try {
      const { userId } = req.params;
      const { domain } = req.body;
      
      if (!domain) {
        return res.status(400).json({ error: "Domain is required" });
      }

      // Basic domain validation
      const domainRegex = /^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,}$/i;
      if (!domainRegex.test(domain)) {
        return res.status(400).json({ error: "Invalid domain format" });
      }

      const newDomain = await storage.addDomain(userId, { domain });
      res.json(newDomain);
    } catch (error) {
      logger.error({ error }, "Error adding domain");
      res.status(500).json({ error: "Failed to add domain" });
    }
  });

  // DELETE /api/users/:userId/domains/:domainId - Delete domain
  app.delete("/api/users/:userId/domains/:domainId", async (req, res) => {
    try {
      const { userId, domainId } = req.params;
      await storage.deleteDomain(userId, domainId);
      res.json({ success: true });
    } catch (error) {
      logger.error({ error }, "Error deleting domain");
      res.status(500).json({ error: "Failed to delete domain" });
    }
  });

  // ========== PROJECT SETTINGS ENDPOINTS ==========
  
  // GET /api/projects/:projectId/settings - Get project settings
  app.get("/api/projects/:projectId/settings", async (req, res) => {
    try {
      const { projectId } = req.params;
      
      // Load from storage or return defaults
      const projectSettings = await storage.getProjectSettings(projectId);
      
      if (projectSettings) {
        res.json(projectSettings);
      } else {
        // Return default settings if none saved yet
        const defaultProjectSettings = {
          workspace: defaultSettings.workspace,
          editor: defaultSettings.editor
        };
        res.json(defaultProjectSettings);
      }
    } catch (error) {
      logger.error({ error }, "Error fetching project settings");
      res.status(500).json({ error: "Failed to fetch project settings" });
    }
  });

  // POST /api/projects/:projectId/settings - Update project settings
  app.post("/api/projects/:projectId/settings", async (req, res) => {
    try {
      const { projectId } = req.params;
      const { workspace, editor } = req.body;
      
      // Validate workspace settings if provided
      if (workspace) {
        const workspaceValidation = settingsSchema.shape.workspace.safeParse(workspace);
        if (!workspaceValidation.success) {
          return res.status(400).json({ 
            error: "Invalid workspace settings", 
            details: workspaceValidation.error.errors 
          });
        }
      }
      
      // Validate editor settings if provided
      if (editor) {
        const editorValidation = settingsSchema.shape.editor.safeParse(editor);
        if (!editorValidation.success) {
          return res.status(400).json({ 
            error: "Invalid editor settings", 
            details: editorValidation.error.errors 
          });
        }
      }
      
      // Save to storage
      const settings = {
        workspace: workspace || defaultSettings.workspace,
        editor: editor || defaultSettings.editor
      };
      
      await storage.saveProjectSettings(projectId, settings);
      
      res.json({ 
        success: true, 
        settings 
      });
    } catch (error) {
      logger.error({ error }, "Error updating project settings");
      res.status(500).json({ error: "Failed to update project settings" });
    }
  });

  const httpServer = createServer(app);
  
  // Initialize Socket.IO
  initializeSocket(httpServer);

  return httpServer;
}
